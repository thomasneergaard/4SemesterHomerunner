from setuptools import find_packages, setup

setup(
    name='HX711',
    packages=['.'],
    version='1.0.0',
    description='HX711 chip interface library',
    author='gandalf15@github',
    license='BSD 3-Clause',
)
